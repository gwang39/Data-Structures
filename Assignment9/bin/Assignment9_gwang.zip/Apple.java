
public class Apple extends Fruit
{
	public Apple()
	{
		super();
	}
	
}
