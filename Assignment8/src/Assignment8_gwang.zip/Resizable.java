
public interface Resizable
{
	void resizeObject();
}
