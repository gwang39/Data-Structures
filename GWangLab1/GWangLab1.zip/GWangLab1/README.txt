DEVELOPMENT IDE

Eclipse IDE for Java Developers
Version: Neon.2 Release (4.6.2)
Build id: 20161208-0600


HOW TO RUN PROGRAM

Eclipse

The program can be ran in Eclopse by importing the parent folder as project and run the main class
Main class: GWangLab1

JDK 6
The source code can be compiled with JDK 6 from the command line with or without argument as below
With Arguement: java GWangLab1 [inputFile]
Without Argument: java GWangLab1

Note: There would be prompt in the console asking for input file location if you choose to run program without command line argument


LANGUAGE DETAILS

L1=  { w: w contains equal numbers of A's and B's (in any order) and no other characters}
L2 = { w: w is of the form AnBn, for some n >= 0 }
L3 = { w: w is of the form AnB2n, for some n >= 0 }
L4 = { w: w is of the form (AnBm)p, for some m,n,p >= 0 }
L5 = { w: w is of the form AnBmC(m+n), for some m,n >= 0 }
L6 = { w: w is of the form AnBmCpDCpBmAn (Reverse after D), for some m,n,p >= 0 }