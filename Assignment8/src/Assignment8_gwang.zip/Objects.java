/**
 * This is the abstract class that implements manipulations of an object
 * 
 */

public abstract class Objects implements Drawable, Rotatable, Resizable, Sounds
{

}
