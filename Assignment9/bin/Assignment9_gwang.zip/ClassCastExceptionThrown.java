/**
 * This program throws ClassCastException
 * @author Guan Yue Wang
 *
 */


public class ClassCastExceptionThrown
{
    public static void main(String[] args) 
    {
    	
    	Fruit oneFruit = new Fruit();
    	
    	Apple oneAple = (Apple)oneFruit;

    	
    }
}
