
public interface Drawable
{
	void drawObject();
}
