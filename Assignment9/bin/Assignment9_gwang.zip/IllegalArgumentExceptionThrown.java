/**
 * This program throws IllegalArgumentException
 * @author Guan Yue Wang
 *
 */

public class IllegalArgumentExceptionThrown 
{

	public static void main(String[] args) 
	{
		
		Character.toChars(-1);
			
	}

}
